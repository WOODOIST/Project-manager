﻿namespace ProjectManagerAPI.DtoObjects
{
    public class RoleDto
    {
        public string Rolename { get; set; } = null!;
    }
}
